# React Context Switching

This project demonstrates how to use React Context API to toggle between light and dark themes.
